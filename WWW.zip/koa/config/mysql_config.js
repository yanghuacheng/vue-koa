const config ={
	user:"root",
	password:"root",
	database:"text",
	port:"3306",
	host:"localhost"
};
module.exports = config;
