class idx{
	constructor(){
		console.log(this.__proto__)
		for (var i in this.__proto__){
			console.log(i)
		}
	}
	sup(){
		console.log(123)
	}
	static go(){
		
	}
}
var obj = new idx()
console.log(obj._proto_)
var newo  = {
	go(){
		console.log(1)
	}
}
console.log(newo.__proto__)
var objs ={
	sup(){
		console.log(111)
	},
	a:1
}
Object.assign(newo,objs)
console.log(newo)
newo.sup()

function nn(){
	this.go = function(){
		
	}
	this.gg = function(){
		
	}
}
console.log(new nn())
for(var i in new nn()){
	console.log(i)
}