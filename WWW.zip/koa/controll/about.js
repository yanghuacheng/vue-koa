// var path = require('path'); 
module.exports = async function(ctx, url) {
	// var par = ctx.request.query//get请求参数
	// var body = ctx.request.body//post请求参数
	var data = {};
	console.log(ctx[url],1)
	await ctx.db.get({
		dbname:"crm_order",
		field:"*",
		where:""
	}).then(function(val){
		data = val;
	});
	// console.log(data)
	await ctx.render(url.substr(1, url.length - 1))
};
