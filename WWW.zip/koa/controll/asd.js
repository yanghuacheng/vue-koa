// var path = require('path'); 
module.exports = async function(ctx, url) {
	// var par = ctx.request.query//get请求参数
	// var body = ctx.request.body//post请求参数
	// var data = {};
	await ctx.db.get({
		dbname:"crm_order",
		field:"*",
		where:""
	}).then(function(val){
		data = val;
	});
	ctx['aa'] = {data}
	// console.log(data)
	await ctx.render('about')
};
