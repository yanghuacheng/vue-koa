/*
Navicat MySQL Data Transfer

Source Server         : db
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : text

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2020-01-02 11:30:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `per`
-- ----------------------------
DROP TABLE IF EXISTS `per`;
CREATE TABLE `per` (
  `perid` int(5) NOT NULL,
  `name` text NOT NULL,
  `per` int(5) NOT NULL COMMENT 'perid权限id  name锛氭潈闄愬悕绉? per锛氭潈闄愮被鍨?',
  PRIMARY KEY (`perid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='perid：权限id\r\nname：权限名称\r\nper：权限类型';

-- ----------------------------
-- Records of per
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `perid` int(5) NOT NULL,
  `username` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '鐢ㄦ埛琛?\n',
  `pass` text NOT NULL,
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `topimg` text,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('0', '杨华成', '57cb5a26334a6c1d5e27c49def4a0f0d', '4', null, '1577267415827');
INSERT INTO `user` VALUES ('0', '小明', '202cb962ac59075b964b07152d234b70', '5', null, '1577267611813');
INSERT INTO `user` VALUES ('0', '小李', '202cb962ac59075b964b07152d234b70', '6', null, '1577610499391');
